// ===== Invoice Items Functions =====
function addItemRow() {
  const tbody = document.querySelector("#invoiceItems tbody");
  const row = document.createElement("tr");
  row.innerHTML = `
        <td><input type="text" class="item-desc"></td>
        <td><input type="number" class="item-qty" min="1" value="1"></td>
        <td><input type="number" class="item-price" step="0.01" min="0"></td>
        <td class="item-total">0.00</td>
        <td><button class="remove-item-btn">×</button></td>
    `;
  tbody.appendChild(row);
  addItemListeners(row);
}

function removeItemRow(button) {
  button.closest("tr").remove();
  calculateTotals();
}

// ===== Initialize Data Stores =====
let clients = JSON.parse(localStorage.getItem("clients")) || [];
let currentInvoice = JSON.parse(localStorage.getItem("currentInvoice")) || {
  items: [],
  taxRate: 10,
  clientId: null,
};

// ===== Core Functions =====
function loadClients() {
  const select = document.getElementById("clientSelect");
  select.innerHTML = '<option value="">Select Client</option>';
  clients.forEach((client) => {
    const option = document.createElement("option");
    option.value = client.id;
    option.textContent = client.name;
    select.appendChild(option);
  });
}

function showClientForm() {
  document.getElementById("clientModal").style.display = "block";
}

function closeClientForm() {
  document.getElementById("clientModal").style.display = "none";
}

// Logo Handling
function loadLogo() {
  const logo = localStorage.getItem("companyLogo");
  if (logo) {
    document.getElementById(
      "logoPreview"
    ).style.backgroundImage = `url(${logo})`;
  }
}

// Item Listeners
function addItemListeners(row) {
  const qtyInput = row.querySelector(".item-qty");
  const priceInput = row.querySelector(".item-price");

  [qtyInput, priceInput].forEach((input) => {
    input.addEventListener("input", () => {
      const qty = parseFloat(qtyInput.value) || 0;
      const price = parseFloat(priceInput.value) || 0;
      row.querySelector(".item-total").textContent = (qty * price).toFixed(2);
      calculateTotals();
    });
  });
}

// Calculations
function calculateTotals() {
  let subtotal = 0;
  document.querySelectorAll(".item-total").forEach((td) => {
    subtotal += parseFloat(td.textContent) || 0;
  });

  const taxRate = parseFloat(document.getElementById("taxRate").value) || 0;
  const taxAmount = subtotal * (taxRate / 100);
  const grandTotal = subtotal + taxAmount;

  document.getElementById("subtotal").textContent = subtotal.toFixed(2);
  document.getElementById("taxAmount").textContent = taxAmount.toFixed(2);
  document.getElementById("grandTotal").textContent = grandTotal.toFixed(2);
}

// ===== Event Listeners =====
window.addEventListener("DOMContentLoaded", () => {
  loadClients();
  loadLogo();
  loadInvoiceDraft();

  document
    .getElementById("newClientBtn")
    .addEventListener("click", showClientForm);
  document
    .querySelector(".modal .close")
    .addEventListener("click", closeClientForm);
  document
    .getElementById("clientSelect")
    .addEventListener("change", handleClientSelection);
  document
    .getElementById("saveDraftBtn")
    .addEventListener("click", saveInvoice);
  document
    .getElementById("generatePDFBtn")
    .addEventListener("click", generatePDF);
  document
    .getElementById("saveClientBtn")
    .addEventListener("click", saveClient);
  document.getElementById("addItemBtn").addEventListener("click", addItemRow);
  document.getElementById("taxRate").addEventListener("input", calculateTotals);

  // Logo input listener
  document.getElementById("logoInput").addEventListener("change", function (e) {
    const reader = new FileReader();
    reader.onload = function () {
      localStorage.setItem("companyLogo", reader.result);
      document.getElementById(
        "logoPreview"
      ).style.backgroundImage = `url(${reader.result})`;
    };
    reader.readAsDataURL(e.target.files[0]);
  });

  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("remove-item-btn")) {
      removeItemRow(e.target);
    }
  });
});

function loadInvoiceDraft() {
  const savedInvoice = localStorage.getItem("currentInvoice");
  if (savedInvoice) {
    try {
      currentInvoice = JSON.parse(savedInvoice);

      // Restore client selection and display
      if (currentInvoice.clientId) {
        document.getElementById("clientSelect").value = currentInvoice.clientId;
        const selectedClient = clients.find(
          (c) => c.id == currentInvoice.clientId
        );
        if (selectedClient) {
          document.getElementById("clientDisplayName").textContent =
            selectedClient.name;
          document.getElementById("clientDisplayEmail").textContent =
            selectedClient.email;
          document.getElementById("clientDisplayAddress").textContent =
            selectedClient.address;
        }
      }

      // Restore tax rate
      document.getElementById("taxRate").value = currentInvoice.taxRate;

      // Restore company info
      document.getElementById("companyName").value =
        currentInvoice.companyName || "";
      document.getElementById("companyEmail").value =
        currentInvoice.companyEmail || "";

      // Restore items
      const tbody = document.querySelector("#invoiceItems tbody");
      tbody.innerHTML = "";
      currentInvoice.items.forEach((item) => {
        const row = document.createElement("tr");
        row.innerHTML = `
                    <td><input type="text" class="item-desc" value="${
                      item.description
                    }"></td>
                    <td><input type="number" class="item-qty" min="1" value="${
                      item.quantity
                    }"></td>
                    <td><input type="number" class="item-price" step="0.01" min="0" value="${
                      item.price
                    }"></td>
                    <td class="item-total">${(
                      item.quantity * item.price
                    ).toFixed(2)}</td>
                    <td><button class="remove-item-btn">×</button></td>
                `;
        tbody.appendChild(row);
        addItemListeners(row);
      });

      // Restore client selection
      if (currentInvoice.clientId) {
        document.getElementById("clientSelect").value = currentInvoice.clientId;
      }

      calculateTotals();
    } catch (e) {
      console.error("Error loading draft:", e);
    }
  }
}

function validateInvoice() {
  // Company validation
  if (!document.getElementById("companyName").value.trim()) {
    alert("Please enter company name");
    return false;
  }

  // Client validation
  const selectedClient = document.getElementById("clientSelect").value;
  if (!selectedClient) {
    alert("Please select a client");
    return false;
  }

  // Items validation (check DOM rows)
  if (document.querySelectorAll("#invoiceItems tbody tr").length === 0) {
    alert("Please add at least one invoice item");
    return false;
  }

  // Validate individual items
  let valid = true;
  document.querySelectorAll("#invoiceItems tbody tr").forEach((row) => {
    const price = parseFloat(row.querySelector(".item-price").value);
    const qty = parseFloat(row.querySelector(".item-qty").value);

    if (isNaN(price) || price <= 0) {
      valid = false;
      row.querySelector(".item-price").classList.add("error");
    }
    if (isNaN(qty) || qty <= 0) {
      valid = false;
      row.querySelector(".item-qty").classList.add("error");
    }
  });

  if (!valid) {
    alert("Please check item quantities and prices");
    return false;
  }

  return true;
}

function saveInvoice() {
  if (!validateInvoice()) return;

  // Create a clean document structure
  const pdfContent = document.createElement("div");
  pdfContent.className = "pdf-content";

  // Clone and prepare content
  const clone = document.querySelector(".container").cloneNode(true);

  // Convert logo background to image
  const logoPreview = clone.querySelector("#logoPreview");
  if (logoPreview.style.backgroundImage) {
    const logoUrl = logoPreview.style.backgroundImage
      .replace('url("', "")
      .replace('")', "");
    const img = document.createElement("img");
    img.src = logoUrl;
    img.style.maxWidth = "150px";
    logoPreview.parentNode.replaceChild(img, logoPreview);
  }

  currentInvoice = {
    clientId: document.getElementById("clientSelect").value,
    companyName: document.getElementById("companyName").value,
    companyEmail: document.getElementById("companyEmail").value,
    items: [],
    taxRate: parseFloat(document.getElementById("taxRate").value) || 0,
    lastSaved: new Date().toISOString(),
  };

  document.querySelectorAll("#invoiceItems tbody tr").forEach((row) => {
    currentInvoice.items.push({
      description: row.querySelector(".item-desc").value,
      quantity: parseFloat(row.querySelector(".item-qty").value),
      price: parseFloat(row.querySelector(".item-price").value),
    });
  });

  localStorage.setItem("currentInvoice", JSON.stringify(currentInvoice));
  alert("Draft saved successfully!");
}

function saveClient() {
  const client = {
    id: Date.now(),
    name: document.getElementById("clientName").value.trim(),
    email: document.getElementById("clientEmail").value.trim(),
    address: document.getElementById("clientAddress").value.trim(),
  };

  if (!client.name) {
    alert("Client name is required");
    return;
  }

  clients.push(client);
  localStorage.setItem("clients", JSON.stringify(clients));
  loadClients();

  // Clear form fields
  document.getElementById("clientName").value = "";
  document.getElementById("clientEmail").value = "";
  document.getElementById("clientAddress").value = "";
  closeClientForm();
}

function generatePDF() {
  if (!validateInvoice()) return;

  const pdfContent = document.createElement('div');
  pdfContent.className = 'pdf-content';
  
  const clone = document.querySelector('.container').cloneNode(true);
  
  // Handle logo with aspect ratio preservation
  const logoPreview = clone.querySelector('#logoPreview');
  if (logoPreview) {
      const logoUrl = localStorage.getItem('companyLogo');
      if (logoUrl) {
          const imgContainer = document.createElement('div');
          imgContainer.style.width = '150px';
          imgContainer.style.height = '150px';
          imgContainer.style.display = 'flex';
          imgContainer.style.alignItems = 'center';
          imgContainer.style.justifyContent = 'center';
          imgContainer.style.overflow = 'hidden';

          const img = document.createElement('img');
          img.src = logoUrl;
          img.style.maxWidth = '100%';
          img.style.maxHeight = '100%';
          img.style.objectFit = 'contain';
          img.style.objectPosition = 'center';

          imgContainer.appendChild(img);
          logoPreview.parentNode.replaceChild(imgContainer, logoPreview);
      }
  }

  // Remove interactive elements (EXCLUDE taxRate input)
  clone.querySelectorAll(
      `.client-section, 
       #clientSelect, 
       button, 
       input[type="file"], 
       .remove-item-btn,
       input[type="number"]:not(#taxRate)`  // Exclude taxRate from removal
  ).forEach(el => el.remove());

  // Convert remaining inputs to text
  clone.querySelectorAll('input, select').forEach(el => {
      const replacement = document.createElement('div');
      replacement.textContent = el.tagName === 'SELECT' 
          ? el.options[el.selectedIndex]?.text || ''
          : el.value;
      el.parentNode.replaceChild(replacement, el);
  });

  pdfContent.appendChild(clone);

  // Create PDF
  const pdf = new jspdf.jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
  });

  // Add content
  pdf.html(pdfContent, {
      callback: function(pdf) {
          pdf.save(`invoice_${document.getElementById('companyName').value}_${Date.now()}.pdf`);
      },
      margin: [15, 15, 15, 15],
      autoPaging: 'text',
      width: 180,
      windowWidth: 800
  });
}

function handleClientSelection() {
  const clientId = this.value;
  const selectedClient = clients.find((c) => c.id == clientId);
  if (selectedClient) {
    document.getElementById("clientDisplayName").textContent =
      selectedClient.name;
    document.getElementById("clientDisplayEmail").textContent =
      selectedClient.email;
    document.getElementById("clientDisplayAddress").textContent =
      selectedClient.address;
  } else {
    document.getElementById("clientDisplayName").textContent = "-";
    document.getElementById("clientDisplayEmail").textContent = "-";
    document.getElementById("clientDisplayAddress").textContent = "-";
  }
}

// Service Worker Registration
if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("/sw.js")
    .then((registration) => console.log("SW registered"))
    .catch((err) => console.log("SW registration failed"));
}
